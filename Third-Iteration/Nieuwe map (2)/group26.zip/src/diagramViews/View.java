package diagramViews;

/**
 * A class which contains different Enum for view.
 * @author Afraz Salim
 *
 */
public enum View {
      SEQUENCE_View,COMM_View,Actor,Party
}
