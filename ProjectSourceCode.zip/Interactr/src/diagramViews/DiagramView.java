package diagramViews;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;
import java.beans.PropertyChangeEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import Exceptions.IllegalObjectException;
import Exceptions.IllegalOperationExcetion;
import controller.DiagramViewController;
import domainObjects.Message;
import domainObjects.Party;
import shapes.PartyShape;


/**
 * A class representing the Diagram view.
 * @author Afraz Salim
 *
 */
public abstract class DiagramView extends ObjectShape{

	
	Random random;
	/**
	 * A private arraylist to store the party list.
	 */
	private ArrayList<Party> partyList;
	/**
	 * A private hashMap to store the partyShape with party.
	 */
	private HashMap<Party,PartyShape> associationList; 
	/**
	 * A private ArrayList which stores the party shape.
	 */
	private ArrayList<PartyShape> shapeList;
	/**
	 * A private hashMap which stores with each message , it's coordinates.
	 */
	private HashMap<Message,Coordinate> messageMap  = new HashMap<>();
	/**
	 * A private hashmap to store an invocation message with resulting messagE.
	 */
	private static HashMap<Message,Message> messageAssociationMap = new HashMap<>();
	/**
	 * A constructor to initialize the data in diagram view.
	 * @param view
	 *        The given view of the diagram.
	 * @param controller
	 *        The given controller of the diagram.
	 * @param x
	 *        The given x-coordinate of the diagram.
	 * @param y
	 *        The given y-coordinate of the diagram.
	 * @param width
	 *        The given width of the diagram.
	 * @param height
	 *        The given height of the diagram.
	 */
	public DiagramView(View view, DiagramViewController controller, int x, int y, int width,int height) {
	         super(controller,view,x,y,width,height);
	         random = new Random();
	         this.setPartyList(new ArrayList<>());
	         this.setAssociationList(new HashMap<>());
	         this.setShapeList(new ArrayList<>());
	         this.getController().getEditLabelHandler().subscribe(this);
	         this.getController().getConvertPartyTypeController().subscribe(this);
	         this.getController().getMessageController().subscribe(this);
	}
	
	/**
	 * A function which acts according to the event recieved.
	 * @param evt
	 *        A parameter which contains a specific event.
	 */
	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		String value = evt.getPropertyName();
		switch(value) {
		case "labelEnabled" : this.enabledLabel(evt);
		      break;
		case "CreatedParty" :  this.createPartyShape(evt);
		      break;
		case "RemoveMessage" : this.removeMessage(evt);
		      break;
		case "RemoveParty" : this.removeParty(evt);
		      break;
		case "ConvertedParty" : this.convertPartyType(evt);
		      break;
		case "MessageFinished" : this.finishMessageCreation(evt);
		      break;
		case "LabelVerified" :  this.setLabelOff(evt);
		      break;
		}
			
	}

	
	
	
	
	/**
	 * Sets the label of the party off after being verified.
	 * @param evt
	 *        The event which contains the new and old text.
	 */
	private void setLabelOff(PropertyChangeEvent evt) {
        Party party = (Party) evt.getNewValue();
        PartyShape shape = this.getAssociationList().get(party);
        this.updateLabelText(evt);
        shape.setLabelActive(false);
	}

	
	/**
	 * A function which updates the text of the label.
	 * @param evt
	 *        An event parameter which contains text of label.
	 */
	private void updateLabelText(PropertyChangeEvent evt) {
         PartyShape shape = this.getAssociationList().get(evt.getNewValue());
         shape.getLabel().setText((String) evt.getOldValue());
	}

	/**
	 * A function which enabled a label.
	 * @param evt
	 *        A parameter which contains the boolean value for activating and deactivatng the shape.
	 */
	private void enabledLabel(PropertyChangeEvent evt) {
		Party party = (Party) evt.getNewValue();
		PartyShape shape = this.getAssociationList().get(party);
		shape.setLabelActive((boolean) evt.getOldValue());
	}

	/**
	 * A function to create the shape of the party.
	 * @param evt
	 *        An event which ontains the newly created party.
	 */
	private void createPartyShape(PropertyChangeEvent evt) {
		if(!(this.hasAnyShapeWithSameSource(evt))) {
			 this.getPartyList().add((Party) evt.getNewValue());
		       this.createShape((Party)evt.getNewValue(),this.getX()+getObjectPositionX(), this.getY()+getObjectPositionY(),null);
		}
	}

	/**
	 * A checker to check if there is alread a partyShape with same party as source.
	 * @param evt
	 *        An event which contains the newly created party.
	 * @return
	 *        Returns true if there is no party with same partyShape.
	 */
	private boolean hasAnyShapeWithSameSource(PropertyChangeEvent evt) {
		for(PartyShape shape : this.getShapeList()) {
			  if(shape.getSource().equals(evt.getNewValue())) 
                 return true;
		}
		 return false;
	}

	/**
	 * A function to remove the message.
	 * @param evt
	 *        An evt parameter which contains the message value to be removed.
	 */
	private void removeMessage(PropertyChangeEvent evt) {
       getMessageMap().remove(evt.getOldValue());
       getMessageMap().remove(getMessageAssociationMap().get(evt.getOldValue()));
       getMessageAssociationMap().remove(evt.getOldValue());
       this.setMessageUnderConstruction(null);
	}
	

	/**
	 * A functionw which removes the party.
	 * @param evt
	 *       A parameter which contains the party to be removed.
	 */
	private void removeParty(PropertyChangeEvent evt) {
       Party old = (Party) evt.getOldValue();
       PartyShape shape = this.getAssociationList().get(old);
       this.getPartyList().remove(old);
       this.getShapeList().remove(shape);
       this.getAssociationList().remove(old);
	}

	/**
	 * A function to finish the message creation process.
	 * @param evt
	 *        A parameter which contains the value of the message.
	 */
	private void finishMessageCreation(PropertyChangeEvent evt) {
		this.setMessageUnderConstruction(null);
	}
	
	
	
	

	
	/**
	 * A function to convert the party's type.
	 * @param evt
	 *        An event which contains the converted party's new value and old value in terms of parties.
	 */
	private void convertPartyType(PropertyChangeEvent evt) {
      PartyShape old = this.getAssociationList().get(evt.getOldValue());
      this.getPartyList().remove(evt.getOldValue());
      this.getAssociationList().remove(evt.getOldValue());
      if(old != null) {
      Party party = (Party) evt.getNewValue();
      this.getPartyList().add(party);
      this.createShape(party, old.getX(), old.getY(), old);
      this.getShapeList().remove(old);
      }
	}

	/**
	 * A function to draw the message.
	 * @param g
	 *        The instance of the graphics to draw the message.
	 */
	protected abstract void drawMessage(Graphics g);
	
	/**
	 * A private variable to store the previous x-clicked.
	 */
	private int previousX;
	/**
	 * A private variable to store the previous y-coordinate.
	 */
	private int previousY;
	/**
	 * A function which performs the mouse action.
	 */
	protected void performMouseAction(int id, int x, int y, int clickCount) {
		if(this.getPartyWithLabelEnabled() != null)
			return;
		MouseAction value = null;
		try {
	           value = this.getValue(id,clickCount);
		 } catch(IllegalObjectException exc) {
			 System.out.print(exc.toString());
			 return;
		 }
          switch(value) {
		case Clicked: this.checkClickEvent(x,y,clickCount);
			break;
		case DoubleClicked: this.checkForDoubleClickEvent(x,y);
			break;
		case Dragged: this.checkForDragEvent(x,y);
			break;
		case Released: this.checkForReleasedEvent(x,y);
			break;
		default:
			break;
          
          }
          this.setPreviousX(x);
          this.setPreviousY(y);
	}

	
	/**
	 * A function which acts when the mouse is released.
	 * @param x
	 *        The x-coordinate on which the mouse is released.
	 * @param y
	 *        The y-coordinate on which the mouse is released.
	 */
	private void checkForReleasedEvent(int x, int y) {
        for(PartyShape shape :this.getShapeList()) {
        	shape.releasedButtion(x, y);
        }
        if(this.getMessageUnderConstruction() != null) {
        	this.getController().getMessageController().finishMessageCreationProcess(this.getMessageUnderConstruction().getSender(), null);
            this.setMessageUnderConstruction(null);
        }
	}

	/**
	 * A function which acts when the mouse is double clicked.
	 * @param x
	 *        The x-coordiante on which mouse is double clicked.
	 * @param y
	 *        The y-coordiante on which mouse is double clicked.
	 */
	private void checkForDoubleClickEvent(int x, int y) {
		ArrayList<PartyShape> temp = new ArrayList<PartyShape>();
		temp.addAll(getShapeList());
       for(PartyShape shape : temp)
    	   shape.doubleClicked(x, y);
	}
	
	/**
	 * A function to resize the diagram.
	 */
	@Override
	protected void resize(int width, int height) {
		
	}


	/**
	 * A fucntion to check for the drag event.
	 * @param x
	 *        The x-coordinate on which the mouse is dragged.
	 * @param y
	 *        The y-coordinate on which the mouse is dragged.
	 */
	private void checkForDragEvent(int x, int y) {
		if(this.getMessageUnderConstruction() != null) {
			this.setMessageUnderConsX(x);
			this.setMessageUnderConsY(y);
			Coordinate temp = getMessageMap().get(getMessageUnderConstruction());
			temp.setY(y);
		}
		else 
			for(PartyShape shape : this.getShapeList())
    	        shape.drag(x, y);
	}

	/**
	 * A function which behaves according to the clickEvent.
	 * @param x
	 *        The x-coordinate on which the mouse is clicked.
	 * @param y
	 *        The y-coordinate on which the mouse is cliked.
	 * @param clickCount
	 *        The number of clicks.
	 */
	private void checkClickEvent(int x, int y, int clickCount) {
		if(this.getMessageUnderConstruction() != null)
			return;
		if(this.getIntersectingMessage(x,y) != null) 
			this.setMessageLabelActive(this.getIntersectingMessage(x, y));
         if(this.isValidPositionToCreateObject(x,y))
        	 this.createNewObject(x,y);
         for(PartyShape shape : this.getShapeList())
        	 shape.mouseClicked(x, y);
	}



	/**
	 * A setter to set the message label active.
	 * @param message
	 *        The message whose label gets activated.
	 */
	public void setMessageLabelActive(Message message) {
       this.getController().getEditLabelHandler().setLabelEnabled(message);
	}
	

	protected abstract Message getIntersectingMessage(int x, int y);
	
	
	
	protected abstract boolean isValidPositionToCreateObject(int x, int y);
	private int getRandomNumber() {
	    return random.nextInt((1 - 0) + 1) + 0;
	}


	private void createNewObject(int x, int y) {
 		if(this.getRandomNumber() == 0)
 			this.createActorObject(x,y);
 		else
 			this.createPartyObject(x,y);
	}



	private static int objectPositionX;
	private static int objectPositionY;
	private void createActorObject(int x, int y) {
		setObjectPositionX(x-this.getX());
		setObjectPositionY(y-this.getY());
		this.getController().getAddPartyController().createActor("");
	}
	
	private Shape getShape() {
		Shape rect = new Rectangle2D.Double(this.getX(),this.getY(),this.getWidht(),this.getHeight());
		return rect;
	}

	protected void paint(Graphics g) {
		Graphics2D g2 = (Graphics2D)g;
		g2.setColor(Color.BLACK);
		g2.draw(this.getShape());
		g2.fill(getShape());
		g2.setColor(Color.WHITE);
	}
	
	protected void createNewCoordinates(Message message) {
		PartyShape sender = this.getAssociationList().get(message.getSender());
		PartyShape reciever = this.getAssociationList().get(message.getReciever());
		int firstY = random.nextInt(((sender.getLine().getY()+sender.getLine().getHeight()-15) - (sender.getLine().getY()+15)) + (sender.getLine().getY()+15));
		int secondY = random.nextInt(((reciever.getLine().getY()+reciever.getLine().getHeight()-15) - (reciever.getLine().getY()+15)) + (reciever.getLine().getY()+15));
		this.getMessageMap().put(message, new Coordinate(secondY,firstY));
	}


	
	private void createPartyObject(int x, int y) {
	   setObjectPositionX(x-this.getX());
	   setObjectPositionY(y-this.getY());
	   this.getController().getAddPartyController().createPartyObject("");
	}



	private MouseAction getValue(int id, int clickCount) {
	    if(id == MouseEvent.MOUSE_RELEASED)
        	return MouseAction.Released;
        if(id == MouseEvent.MOUSE_CLICKED && clickCount == 1)
        	return MouseAction.Clicked;
        if((id == MouseEvent.MOUSE_CLICKED ||id == MouseEvent.MOUSE_RELEASED) && clickCount == 2)
        	return MouseAction.DoubleClicked;
        if(id == MouseEvent.MOUSE_DRAGGED)
        	return MouseAction.Dragged;
	    throw new IllegalObjectException("Event type not supported");
	}

	

	
	protected void createMessage(Message message, int x, int y) {
		getMessageMap().put(message, new Coordinate(y,y));
		this.setMessageUnderConstruction(message);
		this.setMessageUnderConsX(x);
		this.setMessageUnderConsY(y);
	}



	protected void handleKeyEvent(int id, int keyCode, char keyChar) {
		Party party = this.getPartyWithLabelEnabled();
		if(party != null && keyCode != 10 && keyCode != 8)
			this.enterLabel(keyChar,party);
		if(party != null && keyCode == 10)
			this.verifyLabel(party);
		if(party != null && keyCode == 8)
			this.removeText(party);
		if(party != null && keyCode == 127)
			this.removeParty(party);
		if(this.messageWithLabelActive() != null && keyCode != 8)
			this.enterMessageLabelText(this.messageWithLabelActive(),keyChar);
		if(this.messageWithLabelActive() != null && keyCode == 10)
			this.verifyMessageLabel(this.messageWithLabelActive());
		if(this.messageWithLabelActive() != null && keyCode == 8)
			this.removeMessageLabelText(this.messageWithLabelActive());
	}



	
	/**
	 * Removes the last character from the message by calling the operations from domain.
	 * @param messageWithLabelActive
	 *        A message with an active label.
	 */
	public void removeMessageLabelText(Message messageWithLabelActive) {
		try {
		       this.getController().getEditLabelHandler().removeText(messageWithLabelActive);		
		}catch(IllegalOperationExcetion exc) {
			System.out.println(exc.toString());
		}
	}

	
	
	private void verifyMessageLabel(Message message) {
      this.getController().getEditLabelHandler().verifyText(message);		
	}

	
	
	
	/**
	 * A function which enters message's label by calling the controller.
	 * @param messageWithLabelActive
	 *        A message which has active label.
	 * @param keyChar
	 *        The character which needs to be inserted.
	 */
	public void enterMessageLabelText(Message messageWithLabelActive, char keyChar) {
         this.getController().getEditLabelHandler().enterText(keyChar, messageWithLabelActive);		
	}
	
	

	private Message messageWithLabelActive() {
		for(Party party : this.getPartyList()) {
			for(Message message  : party.getSenderList())
				if(message.isActive())
					return message;
		}
		return null;
	}

	private void removeParty(Party party) {
      this.getController().getAddPartyController().remove(party);		
	}

	private void removeText(Party party) {
       PartyShape shape = this.getAssociationList().get(party);
       shape.removeText();
	}

	private void verifyLabel(Party party) {
		PartyShape shape = this.getAssociationList().get(party);
        this.getController().getEditLabelHandler().verifyText(party,shape.getLabel().getText());		
	}

	private void enterLabel(char keyChar, Party party) {
		if(Character.isAlphabetic(keyChar) ||keyChar == ':') {
		PartyShape shape = this.getAssociationList().get(party);
		shape.getLabel().setText(shape.getLabel().getText()+ Character.toString(keyChar));
		}
	}

	protected Party getPartyWithLabelEnabled() {
        for(PartyShape party : this.getShapeList())
        	if(party.getHasActiveLabel())
        		return party.getSource();
		return null;
	}

	protected ArrayList<Party> getPartyList() {
		return partyList;
	}



	protected void setPartyList(ArrayList<Party> partyList) {
		this.partyList = partyList;
	}



	protected HashMap<Party,PartyShape> getAssociationList() {
		return associationList;
	}



	protected void setAssociationList(HashMap<Party,PartyShape> associationList) {
		this.associationList = associationList;
	}




	protected abstract void createShape(Party party, int x, int y, PartyShape shape);




	protected abstract boolean canCreate(int x, int y);




	/**
	 * Moves the party to the given point.
	 * @param x
	 *        The x-coordinate of the point.
	 * @param y
	 *        The y-coordinate of the point.
	 * @param source
	 *        Party which will be moved.
	 */
	public abstract void move(int x, int y, Party source);




	/**
	 * A getter to get the list of all the shapes.
	 * @return
	 *       Returns the list of all the shapes.
	 */
	public ArrayList<PartyShape> getShapeList() {
		return shapeList;
	}




	private void setShapeList(ArrayList<PartyShape> shapeList) {
		this.shapeList = shapeList;
	}


	/**
	 * A function to convert the party's type.
	 * @param x
	 *        The x-coordinate which needs to be converted.
	 * @param y
	 *        The y-coordinate which needs to be converted.
	 * @param source
	 *        The given party which will be converted.
	 */
	public void convertPartyType(int x, int y, Party source) {
		this.getController().getConvertPartyTypeController().convertPartyType(source);
	}

	protected int getPreviousX() {
		return previousX;
	}

	protected void setPreviousX(int previousX) {
		this.previousX = previousX;
	}
	
	private int messageUnderConsX;
	private  int messageUnderConsY;
	private Message messageUnderConstruction;

	/**
	 * A function to create the message.
	 * @param x
	 *        The x-coordinate of the first point where message creation should be started.
	 * @param y
	 *        The y-coordinate of the first point where message creation should be started.
	 * @param source
	 *        The party which creates message.
	 */
	public void createMessage(int x, int y, Party source) {
     Message message =  this.getController().getMessageController().createMessage(source, "");
     this.createMessage(message, x, y);
	}
	

	/**
	 * A getter to get y-coordinate of the message.
	 * @return
	 *       Returns the y-coordinate of the message which is under construction.
	 */
	protected int getMessageUnderConsY() {
		return messageUnderConsY;
	}

	
	/**
	 * A setter to set the y-coordinate of the message which is udner construction.
	 * @param messageUnderConsY
	 *        Y-coordinate of the message which is under construction.
	 */
	private void setMessageUnderConsY(int messageUnderConsY) {
		this.messageUnderConsY = messageUnderConsY;
	}

	/**
	 * A getter to get the message coordinate which is under construction.
	 * @return
	 *       Returns the x-coordinate of the message which is under construction.
	 */
	protected int getMessageUnderConsX() {
		return messageUnderConsX;
	}

	/**
	 * Sets the x-coordinate of the message which is under construction.
	 * @param messageUnderConsX
	 *        The x-coordinate of the message which is under construction.
	 */
	private void setMessageUnderConsX(int messageUnderConsX) {
		this.messageUnderConsX = messageUnderConsX;
	}

	/**
	 * A geter to get the message which is under construction.
	 * @return
	 *       Returns the message under construction.
	 */
	protected Message getMessageUnderConstruction() {
		return messageUnderConstruction;
	}

	/**
	 * A setter to set the message which is under construction.
	 * @param message
	 *        The message which is under construction.
	 */     
	private void setMessageUnderConstruction(Message message) {
		this.messageUnderConstruction = message;
	}

	/**
	 * A getter to get the message map.
	 * @return
	 *       Returns the map of the message.
	 */
	protected HashMap<Message,Coordinate> getMessageMap() {
		return messageMap;
	}

	/**
	 * A setter to set the map for the message.
	 * @param message
	 *        A map which has message's coordinate for each message.
	 */
	protected  void setMessageMap(HashMap<Message,Coordinate> message) {
		this.messageMap = message;
	}
	


	/**
	 * Adjusts the parameter of the diagram and all the parties in it.
	 * @param map
	 *        A map containing the Shap for each party.
	 */
	public void adjustParameter(HashMap<Party, PartyShape> map) {
		for(Party party : this.getPartyList()) {
			PartyShape shape = map.get(party);
			if(shape != null) {
            int x = shape.getX() - shape.getDiagram().getX();
            int y = shape.getY() - shape.getDiagram().getY();
			this.createShape(party, this.getX()+x, this.getY()+y, shape);
			}
		}
		
	}
	
	/**
	 * Ends the message creation process.
	 * @param shape
	 *        Shape of the party which detects a mouse release on it's lifeline and ends message.
	 * @param x
	 *        The x-coordinate of the shape's lifeline.
	 * @param y
	 *        The y-coordinate of the shape's lifeline.
	 */
	public void endMessageProcess(PartyShape shape, int x, int y) {
         if(this.getMessageUnderConstruction() != null) {
           if(shape != null) {
        	  Message message = this.createResultingMessage(shape,this.getMessageUnderConstruction());
        	  Coordinate temp = getMessageMap().get(this.getMessageUnderConstruction());
               getMessageMap().put(message, new Coordinate(temp.getY()+8,temp.getX()+8));
               getMessageAssociationMap().put(this.getMessageUnderConstruction(), message);
              }
	       this.getController().getMessageController().finishMessageCreationProcess(this.getMessageUnderConstruction().getSender(), shape.getSource());	
         }
	}

	
	

	/**
	 * A function which creates a resulting message by calling the controller.
	 * @param shape
	 *        The shape of the party which creates the message.
	 * @param message
	 *        The message for which a resulting message is created.
	 * @return
	 *       Returns a new resulting message.
	 */
	private Message createResultingMessage(PartyShape shape, Message message) {
          return this.getController().getMessageController().createResultingMessage(shape.getSource(),message.getSender(), "");
	}

	

	/**
	 * A getter to get the previous y-coordinate.
	 * @return
	 *        Returns the previous y-coordinates.
	 */
	protected int getPreviousY() {
		return previousY;
	}

	/**
	 * A setter to set the previous y-cordinates.
	 * @param previousY
	 *        The previous y-coordinate where mouse was clicked.
	 */
	protected void setPreviousY(int previousY) {
		this.previousY = previousY;
	}
	

	/**
	 * A function which moves the party's shape at the given points.
	 */
	@Override
	public void move(int x, int y) {
		this.getPartyList().stream().forEach(e -> {
			this.moveMesssage(y,e.getSenderList());
		});
		this.getShapeList().stream().forEach(e -> e.move(e.getX()+ (x-this.getX()), e.getY() + (y-this.getY())));
		this.setX(x);
		this.setY(y);
	}
	
	

	/**
	 * A function which moves the messages.
	 * @param y
	 *        The given y-coordinate of the message.
	 * @param senderList
	 *        A list of the messages sent by a specific party.
	 */
	private void moveMesssage(int y, ArrayList<Message> senderList) {
       for(Message message : senderList) {
    	   Coordinate temp = getMessageMap().get(message);
    	   if(temp == null)
    		   return;// Bug needs to resolved in 3rd iteration
    	   temp.setX(temp.getX() + (y-this.getY()));
    	   temp.setY(temp.getY()+(y-this.getY()));
       }
	}

	/**
	 * A getter to get the to be created object's position.
	 * @return
	 *       Returns the position of the object which will be created.
	 */
	protected static int getObjectPositionX() {
		return objectPositionX;
	}

	/**
	 * A setter to set the objects positon.
	 * @param x
	 *        The new x-coordinate.
	 */
	protected static void setObjectPositionX(int x) {
		objectPositionX = x;
	}

	/**
	 * A getter to get the obejcts y-coordinate.
	 * @return
	 *       Returns the y-coordinate of the object.
	 */
	protected static int getObjectPositionY() {
		return objectPositionY;
	}

	/**
	 * A setter to set the object's positions.
	 * @param y
	 *        The y-coordinate on which the object will be created.
	 */
	protected static void setObjectPositionY(int y) {
		objectPositionY = y;
	}

	/**
	 * A function to create shapes for all of parties.
	 * @param map
	 *        The map which contains party shapes with each party.
	 */
	protected void createShapesForAllParties(HashMap<Party,PartyShape> map) {
         for(Party party : this.getPartyList()) {
        	 PartyShape shape = map.get(party);
        	 if(shape != null)
        	  this.createShape(party, shape.getX(), shape.getY(), shape);
         }
	}

	/**
	 * A getter to get the messaga association.
	 * @return
	 *       Returns the message association map.
	 */
	protected static HashMap<Message,Message> getMessageAssociationMap() {
		return messageAssociationMap;
	}

	public void transFerMessageCoords(DiagramView diagram) {
         diagram.getPartyList().stream().forEach(e -> {
    	 for(Message message : e.getSenderList()) {
    		 Coordinate old = diagram.getMessageMap().get(message);
    		 getMessageMap().put(message, new Coordinate(old.getX(),old.getY()));
    	 }
      });		
	}

	public boolean canResize(int width, int height) {
		for(PartyShape shape : this.getShapeList()) {
			if(shape.getX()+shape.getWidth() > this.getX()+this.getWidht()+width)
				return false;
			if(shape.getLine().getY()+shape.getLine().getHeight() > this.getY()+this.getHeight()+height)
				return false;
		}
		return true;
	}


	
	
	
}
