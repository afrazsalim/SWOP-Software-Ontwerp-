package diagramViews;
/**
 * An enum class representing few mouse event.
 * @author Afraz Salim
 *
 */
public enum MouseAction {
     Clicked,Dragged, DoubleClicked, Released
}
