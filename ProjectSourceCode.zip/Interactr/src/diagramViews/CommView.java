package diagramViews;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import java.util.HashMap;
import java.util.Random;

import Exceptions.IllegalOperationExcetion;
import controller.DiagramViewController;
import domainObjects.Actor;
import domainObjects.InvocationMessage;
import domainObjects.Message;
import domainObjects.Party;
import domainObjects.PartyObject;
import shapes.ActorShapeCommView;
import shapes.PartyObjectCommView;
import shapes.PartyShape;

/**
 * A class represeting the communication view.
 * @author Afraz Salim
 *
 */
public class CommView extends DiagramView {
	
	/**
	 * A private variable which stores the height of the actor in comm view.
	 */
	private int ActorShapeHeight = 90;
	/**
	 * A private variable which stores the width of the actor in comm view.
	 */
	private int actorShapeWidth = 80;
	/**
	 * A private variable which stores the height of the label.
	 */
	private int labelheight = 20;
	/**
	 * A private masp which stores the message with it's coordinates.
	 */
	private HashMap<Message,Coordinate> map;
	/**
	 * A constructor to initialize the view.
	 * @param view
	 *        The current view of the diagram.
	 * @param diagramViewController
	 *        The controller of the diagram.
	 * @param x
	 *        The x coordinate of the diagram.
	 * @param y
	 *        The y-coordinate of the diagram.
	 * @param width
	 *       The width of the diagram.
	 * @param height
	 *       The height of the diagram.
	 */
	public CommView(View view,DiagramViewController diagramViewController,int x, int y, int width, int height) {
		super(view, diagramViewController,x,y,width,height);
		this.setMap(new HashMap<>());
	}

	
	/**
	 * A functionw which paints this view.
	 * @param g
	 *        The instance of the graphics with which diagram will get painted.
	 */
	@Override
	protected void paint(Graphics g) {
		super.paint(g);
		Graphics2D g2 = (Graphics2D)g;
		g2.setColor(Color.GREEN);
		 for(PartyShape shape : this.getShapeList()) {
	        	g2.setColor(Color.WHITE);
	        	g2.draw(shape.getShape());
	        	g2.draw(shape.getLine().getShape());
	        	g2.setColor(Color.WHITE);
	    		g2.setFont(new Font("TimesRoman", Font.PLAIN, 15)); 
	        	if(shape.getHasActiveLabel()) {
	        		g2.setColor(Color.RED);
		        	g2.drawString(shape.getLabel().getText()+"|", shape.getLabel().getX()+2, shape.getLabel().getY()+shape.getLabel().getHeight()-2);
	        	}
	        	else
	        	{
	        	g2.drawString(shape.getLabel().getText(), shape.getLabel().getX()+2, shape.getLabel().getY()+shape.getLabel().getHeight()-2);
	        	}
	        	g2.draw(shape.getLabel().getShape());
	        	g2.setColor(Color.WHITE);
	        	shape.getLine().draw(g);
	        	this.drawMessage(g2);
	        //	this.move(this.getX(), this.getY()); // Bug for realignment
	        }
	}
	
	/**
	 * A getter which returns the width of the actor widht.
	 * @return
	 *       Returns the width of the actor.
	 */
	protected int getActorShapeWidth() {
		return actorShapeWidth;
	}

	/**
	 * A setter to set the width of the actor.
	 * @param actorShapeWidth
	 *        The new width of the actor.
	 */
	protected void setActorShapeWidth(int actorShapeWidth) {
		this.actorShapeWidth = actorShapeWidth;
	}

	/**
	 * A getter to get the height of the label.
	 * @return
	 *       Returns the height of the label.
	 */
	protected int getLabelheight() {
		return labelheight;
	}

	/**
	 * A setter to set the height of the label.
	 * @param labelheight
	 *        The new height of the label.
	 */
	protected void setLabelheight(int labelheight) {
		this.labelheight = labelheight;
	}

	/**
	 * A getter to get the height of the actor in comm view.
	 * @return
	 *       Returns the height of the actor.
	 */
	protected int getActorShapeHeight() {
		return ActorShapeHeight;
	}
	

	/**
	 * A setter to set the height of the actor.
	 * @param actorShapeHeight
	 *         The height of the actor shape.
	 */
	protected void setActorShapeHeight(int actorShapeHeight) {
		ActorShapeHeight = actorShapeHeight;
	}



	
	/**
	 * A function which draws the message.
	 */
	@Override
	protected void drawMessage(Graphics g) {
	  for(Party party : this.getPartyList()) {
		  if(party.getSenderList().size() > 0) {
              for(Message message  : party.getSenderList()) {
            	  System.out.println("CCCCCCCCCCCOOOOOOOOOOOm " + message.getSender());
            	if(message instanceof InvocationMessage)
            	  this.drawMessage(g,message);
              }
		  }
	  }
	}


	
	/**
	 * A functionw which draws the message.
	 * @param g
	 *        The isntance of grahics with which it draws messages.
	 * @param message
	 *       The given message which will be drawn.
	 */
	private void drawMessage(Graphics g, Message message) {
		Graphics2D g2 = (Graphics2D)g;
		PartyShape sender = this.getAssociationList().get(message.getSender());
		if(message.equals(getMessageUnderConstruction()) || message.getReciever() == null) {
			return;
		}
		PartyShape reciever = this.getAssociationList().get(message.getReciever());
		if(this.getMessageMap().get(message) == null)
			this.createNewCoordinates(message);
	    Coordinate temp = this.getMessageMap().get(message);
	    this.adjustCoordinates(sender,reciever,temp);
	    int x = 0;
	    int xSecond = 0;
	    if(sender.getX() > reciever.getX()) {
	    	x = sender.getLine().getX();
	    	xSecond = reciever.getLine().getWidth()+reciever.getLine().getX();
	    }
	    else
	    {
	    	x  = sender.getLine().getX()+sender.getLine().getWidth();
	    	xSecond = reciever.getX();
	    } 
	    int xCo  =this.getXCo(sender,reciever);
	    g.drawLine(x, temp.getX(), xSecond,temp.getY());
	    this.saveMessageLabelCoords(xCo,temp.getX()+(temp.getY()-temp.getX()), message);
        if(message.isActive())
        	g.setColor(Color.RED);
	    this.drawText(g2, message,xCo, temp.getX()+(temp.getY()-temp.getX()));
	    g.setColor(Color.WHITE);
	}
	

	
	private int getXCo(PartyShape sender, PartyShape reciever) {
       if(sender.getX() < reciever.getX()) {
    	   int first = sender.getLine().getX()+sender.getLine().getWidth();
    	   int second = reciever.getLine().getX();
    	   return first +(second-first)/2;
       }
       else {
    	int first = sender.getLine().getX()+sender.getLine().getWidth();
	   int second = reciever.getLine().getX();
	   return second - (second-first)/2;
       }
	}




	private void drawText(Graphics g, Message message, int x, int y) {
		g.setFont(new Font("TimesRoman", Font.PLAIN, 15)); 
		g.drawString("<<"+message.getLabelText()+">>", x, y+15);
	}
	
	
	private void saveMessageLabelCoords(int x, int y, Message message) {
		Coordinate temp = null;
		temp = this.getMap().get(message);
		if(temp == null) {
			this.getMap().put(message, new Coordinate(x,y));
			temp = this.getMap().get(message);
		}
		temp.setX(x);
		temp.setY(y);
	}


	

	


	private void adjustCoordinates(PartyShape sender, PartyShape reciever, Coordinate temp) {
           if(temp.getX() > sender.getY() + sender.getHeight() || temp.getX() < sender.getY())
        	   temp.setX(random.nextInt(((sender.getY()+sender.getHeight()) - sender.getY()) + (sender.getY()+sender.getHeight())) + sender.getY());
           if(temp.getY() > reciever.getY()+reciever.getHeight() || temp.getY() < reciever.getY())
        	   temp.setY(random.nextInt(((reciever.getY()+reciever.getHeight()) - reciever.getY()) + (reciever.getY()+reciever.getHeight())) + reciever.getY());
	}


	@Override
	protected void createShape(Party party, int x, int y, PartyShape shape) {
		 if(party instanceof Actor)
	    	 this.createActorShape(party,x,y,shape);
	     else if(party instanceof PartyObject)
	    	 this.createPartyObjectShape(party,x,y,shape);
	     else throw new IllegalOperationExcetion("Party type not supported");		
	}


	private void createPartyObjectShape(Party party, int x, int y, PartyShape shap) {
		  PartyShape shape = new PartyObjectCommView(this,x,y, this.getActorShapeWidth(), this.getActorShapeHeight());		
	      shape.setSource(party);
	      this.getShapeList().add(shape);
	      this.getAssociationList().put(party, shape);
	      if(shap != null) {
	    	  shape.getLabel().setText(shap.getLabel().getText());
	    	  shape.setLabelActive(false);
	      }
	}


	private void createActorShape(Party party, int x, int y, PartyShape shape) {
		   PartyShape shap = new ActorShapeCommView(this,x, y, this.getActorShapeWidth(), this.getActorShapeHeight());		
		   shap.setSource(party);
		   this.getShapeList().add(shap);
		   this.getAssociationList().put(party, shap);		
		   if(shape != null) {
		      shap.getLabel().setText(shape.getLabel().getText());
	    	  shap.setLabelActive(false);
		   }

	}


	@Override
	protected boolean canCreate(int x, int y) {
		return false;
	}

	Random random = new Random();

	/**
	 * A function to move the party at the give location.
	 * @param x
	 *        The given x-coordinate of the point.
	 * @param y
	 *        The given y-coordinate of the point.
	 * @param party
	 *        The given party whose shape should be moved.
	 */
	@Override
	public void move(int x, int y, Party party) {
		 if(this.getController().getMoveController().canMove()) {
			  PartyShape shape = this.getAssociationList().get(party);
			  if(this.canMove(shape,(x-this.getPreviousX()),(y-this.getPreviousY()))) {
		        if(x-this.getPreviousX() < 5 && x- this.getPreviousX() > -5 ) {
		           shape.move(shape.getX()+(x-this.getPreviousX()), shape.getY()+(y-this.getPreviousY()));
		        }
			  }
			}		
	     }


	private boolean canMove(PartyShape shape, int x, int y) {
        if(shape.getX()+x +this.getActorShapeWidth() > this.getX()+this.getWidht())
        	return false;
        if(shape.getX()+x < this.getX())
        	return false;
        if(shape.getY()+y+this.getActorShapeHeight() > this.getY()+this.getHeight())
        	return false;
        if(shape.getY()+y < this.getY())
        	return false;
		return true;
	}


	@Override
	protected boolean isValidPositionToCreateObject(int x, int y) {
		if(x + this.getActorShapeWidth() > this.getX()+ this.getWidht())
			return false;
		if(y + this.getActorShapeHeight() > this.getY()+this.getHeight())
			return false;
		if(this.getIntersectingMessage(x, y) != null)
			return false;
		 if(!(this.contains(x, y)))
	        	return false;
	        for(PartyShape shape : this.getShapeList()) {
	        	if(shape.contains(x, y)|| shape.getLabel().contains(x, y) || shape.getLine().contains(x, y))
	        		return false;
	        }
		return true;
	}



	@Override
	protected Message getIntersectingMessage(int x, int y) {
		for(Party party : this.getPartyList()) {
			for(Message message : party.getSenderList()) {
				if(message instanceof InvocationMessage) {
				Coordinate temp = this.getMap().get(message);
				Shape rect = new Rectangle2D.Double(temp.getX(),temp.getY(),50,30);
				if(rect.contains(x,y))
					return message;
				}
			}
		}
		return null;
	}


	private HashMap<Message,Coordinate> getMap() {
		return map;
	}


	private void setMap(HashMap<Message,Coordinate> map) {
		this.map = map;
	}


	
	


	


	







}
