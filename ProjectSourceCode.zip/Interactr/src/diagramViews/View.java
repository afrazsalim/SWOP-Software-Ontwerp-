package diagramViews;


public enum View {
      SEQUENCE_View,COMM_View,Actor,Party
}
