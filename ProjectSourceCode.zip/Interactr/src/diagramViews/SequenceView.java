package diagramViews;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.GeneralPath;
import java.awt.geom.Rectangle2D;
import java.util.HashMap;

import Exceptions.IllegalOperationExcetion;
import controller.DiagramViewController;
import domainObjects.Actor;
import domainObjects.InvocationMessage;
import domainObjects.Message;
import domainObjects.Party;
import domainObjects.PartyObject;
import shapes.ActorShapeSequenceView;
import shapes.PartyObjectSequenceView;
import shapes.PartyShape;


/**
 * A class representing the sequence view of the diagram.
 * @author Afraz Salim
 *
 */
public class SequenceView extends DiagramView {
	
	
	private int ActorShapeHeight = 70;
	private int actorShapeWidth = 70;
	private int labelheight = 20;
	private int fixedY = this.getY() + 20;
	private HashMap<Message,Coordinate> map;
	
	/**
	 * A constructor to create the sequence view.
	 * @param view
	 *        The current view of the diagram.
	 * @param diagramViewController
	 *        The current controller of the diagram with which it sends events to the domain.
	 * @param x
	 *        The x-coordinate of the view.
	 * @param y
	 *        The y-coordinate of they view.
	 * @param width
	 *       The width of the view.
	 * @param height
	 *        The height of the view.
	 */
	public SequenceView(View view, DiagramViewController diagramViewController, int x, int y, int width,int height) {
		super(view, diagramViewController, x, y, width, height);
		this.setMap(new HashMap<>());
	}
	
	
	

	/**
	 * A checker to check if the give position is a valid position to create a party object.
	 */
	@Override
	protected boolean isValidPositionToCreateObject(int x, int y) {
		if(x + this.getActorShapeWidth() > this.getX()+ this.getWidht())
			return false;
		if(y + this.getActorHeight() > this.getY()+this.getHeight())
			return false;
		if(this.getIntersectingMessage(x, y) != null)
			return false;
		 if(!(this.contains(x, y)))
	        	return false;
	        for(PartyShape shape : this.getShapeList()) {
	        	if(shape.contains(x, y)|| shape.getLabel().contains(x, y) || shape.getLine().contains(x, y))
	        		return false;
	        }
		return true;
		
	}

	
	



	



	private int getActorShapeWidth() {
		return actorShapeWidth;
	}




	






	
	private int getActorHeight() {
		return this.ActorShapeHeight;
	}
	

	private int getPartyObjectheight() {
		return 60;
	}



	private int getFixedY() {
		return this.getY() + 25;
	}









	/**
	 * A checker to check whether an object can be created.
	 */
	@Override
	protected boolean canCreate(int x, int y) {
		return true;
	}







	/**
	 * A function to create the party's shape.
	 */
	@Override
	protected void createShape(Party party,int x, int y,PartyShape shape) {
     if(party instanceof Actor)
    	 this.createActorShape(party,x,y,shape);
     else if(party instanceof PartyObject)
    	 this.createPartyObjectShape(party,x,y,shape);
     else throw new IllegalOperationExcetion("Party type not supported");
	}







	private void createActorShape(Party party, int x, int y, PartyShape shapes) {
      PartyShape shape = new ActorShapeSequenceView(this,x, this.getFixedY(), this.getActorShapeWidth(), this.getActorHeight());		
	  shape.setSource(party);
      this.getShapeList().add(shape);
      if(shapes != null) {
        shape.getLabel().setText(shapes.getLabel().getText());
        shape.setLabelActive(false);
      }
      this.getAssociationList().put(party, shape);
	}


	/**
	 * A function to move the party's shape.
	 */
	@Override
	public void move(int x, int y, Party source) {
		 if(this.getController().getMoveController().canMove()) {
		  PartyShape shape = this.getAssociationList().get(source);
		   if(this.canMove(x-this.getPreviousX(),shape)) {
	        if(x-this.getPreviousX() < 5 && x- this.getPreviousX() > -5) {
	           shape.move(shape.getX()+(x-this.getPreviousX()), this.getFixedY());	
	        }
		 }
	    }
	}





	

	

	private boolean canMove(int x, PartyShape shape) {
        if(shape.getX() + x+this.getActorShapeWidth() > this.getX()+this.getWidht())
        	return false;
        if(shape.getX()+x <this.getX())
        	return false;
		return true;
	}










	/**
	 * A paint function to paint the view.
	 */
	@Override
	protected void paint(Graphics g) {
		super.paint(g);
		Graphics2D g2 = (Graphics2D)g;
		 for(PartyShape shape : this.getShapeList()) {
				g2.setColor(Color.GREEN);
	        	g2.draw(shape.getShape());
	        	g2.setColor(Color.LIGHT_GRAY);
	        	g2.draw(shape.getLine().getShape());
	        	g2.setColor(Color.LIGHT_GRAY);
	        	g2.fill(shape.getLine().getShape());
	        	g2.setColor(Color.orange);
	    		g2.setFont(new Font("TimesRoman", Font.PLAIN, 15)); 
	        	if(shape.getHasActiveLabel()) {
	        		g2.setColor(Color.RED);
		        	g2.drawString(shape.getLabel().getText()+"|", shape.getLabel().getX(), shape.getLabel().getY()+shape.getLabel().getHeight()-2);
	        	}
	        	else
		        	g2.drawString(shape.getLabel().getText(), shape.getLabel().getX(), shape.getLabel().getY()+shape.getLabel().getHeight()-2);
	        	g2.draw(shape.getLabel().getShape());
	        	g2.setColor(Color.WHITE);
	        	shape.getLine().draw(g);
	        	g2.setColor(Color.WHITE);
	        	this.drawMessage(g2);
	        	this.move(this.getX(), this.getY()); // Bug for realignment
	        }

	}







	private void createPartyObjectShape(Party party, int x, int y, PartyShape shap) {
	      PartyShape shape = new PartyObjectSequenceView(this,x, this.getFixedY(), this.getActorShapeWidth(), this.getPartyObjectheight());		
	      shape.setSource(party);
	      this.getShapeList().add(shape);
	      if(shap != null) {
	       shape.getLabel().setText(shap.getLabel().getText());
	        shape.setLabelActive(false);
	      }
	      this.getAssociationList().put(party, shape);
	}







	@Override
	protected void drawMessage(Graphics g) {
	  for(Party party : this.getPartyList()) {
		  if(party.getSenderList().size() > 0) {
              for(Message message  : party.getSenderList()) {
            	  Message mess  =getMessageAssociationMap().get(message);
            	  if(mess != null)
            	    this.drawMessage(g,mess);
              }
              for(Message message : party.getSenderList()) {
            	  if(!(message.equals(getMessageUnderConstruction())) && message instanceof InvocationMessage) {
            		  this.drawInvocationMessage(g,message);
            	  }
            	  if(message.equals(getMessageUnderConstruction()))
            		  this.drawMessage(g,message);
              }
		  }
	  }
	}















	






	private void drawInvocationMessage(Graphics g, Message message) {
		Graphics2D g2 = (Graphics2D)g;
		float[] dashes = {1,1,1};
     	BasicStroke stroke = new BasicStroke(1, BasicStroke.CAP_SQUARE, BasicStroke.CAP_SQUARE, 10, dashes, 10);
        Message resulting  = getMessageAssociationMap().get(message);	
        Coordinate temp = getMessageMap().get(resulting);
        PartyShape sender = this.getAssociationList().get(message.getSender());
        PartyShape reciever = this.getAssociationList().get(message.getReciever());
        if(sender == null ||reciever == null)
        	return;
        int y = temp.getX()-(sender.getLine().getActivationBarHeigth()-2);
        int ySecond = temp.getY()-(reciever.getLine().getActivationBarHeigth()-2);
        int index = this.getIndex(sender);
        Shape shape = this.getResultingShape(sender, reciever, ySecond, y, index);
        Shape stroked = stroke.createStrokedShape(shape);
        g2.draw(stroked);
        int labelX = this.getLabelX(sender,reciever);
        if(message.isActive())
        	g.setColor(Color.RED);
        this.saveLabelCoordinate(message,labelX,temp.getX()-sender.getLine().getActivationBarHeigth()+(temp.getY()-temp.getX()));
	    this.drawText(g,message,labelX,temp.getX()-sender.getLine().getActivationBarHeigth()+(temp.getY()-temp.getX()));
        if(message.isActive())
        	g.setColor(Color.RED);
	    g.setColor(Color.WHITE);
	}
	
	

	private int getLabelX(PartyShape sender, PartyShape reciever) {
        if(sender.getX() < reciever.getX()) {
        	return sender.getLine().getX()+(Math.abs(reciever.getLine().getX() - sender.getLine().getX())/2);
        }
		return reciever.getLine().getX()+(Math.abs(reciever.getLine().getX() - sender.getLine().getX())/2);
	} 




	private void drawText(Graphics g, Message message, int x, int y) {
		g.setFont(new Font("TimesRoman", Font.PLAIN, 15)); 
		g.drawString("<<"+message.getLabelText()+">>", x, y+15);
	}

	private void saveLabelCoordinate(Message message, int x, int y) {
		Coordinate temp = null;
		temp = this.getMap().get(message);
		if(temp == null) {
			this.getMap().put(message, new Coordinate(x,y));
			temp = this.getMap().get(message);
		}
		temp.setX(x);
		temp.setY(y);
	 }


	

	private void drawMessage(Graphics g, Message message) {
		Graphics2D g2 = (Graphics2D)g;
		PartyShape sender = this.getAssociationList().get(message.getSender());
		int index = this.getIndex(sender);
		float[] dashes = {8,8,8};
     	BasicStroke stroke = new BasicStroke(1, BasicStroke.CAP_SQUARE, BasicStroke.CAP_SQUARE, 10, dashes, 10);
     	if(this.getMessageUnderConstruction() != null && message.equals(this.getMessageUnderConstruction())) {
    	   this.clearAllBars(sender);
    	   Coordinate temp = getMessageMap().get(this.getMessageUnderConstruction());
    	   if(!(sender.getLine().hasActivationBarAt(sender.getLine().getX()-sender.getLine().getActivationBarWidth()/2, temp.getX())))
    		   sender.getLine().createActivationBar(sender.getLine().getX()-sender.getLine().getActivationBarWidth()/2, temp.getX()-sender.getLine().getActivationBarHeigth());
    	   GeneralPath path = new GeneralPath();
    	   int arrow  = this.getArrow(sender.getLine().getX()+index*sender.getLine().getActivationBarWidth()/2, temp.getX(),this.getMessageUnderConsX(), temp.getY());
    	   path.moveTo(sender.getLine().getX()+index*sender.getLine().getActivationBarWidth()/2, temp.getX());
    	   path.lineTo(this.getMessageUnderConsX(), temp.getY());
    	   path.moveTo(this.getMessageUnderConsX()+arrow, temp.getY()-5);
    	   path.lineTo(this.getMessageUnderConsX(), temp.getY());
    	   path.moveTo(this.getMessageUnderConsX()+arrow, temp.getY()+5);
    	   path.lineTo(this.getMessageUnderConsX(), temp.getY());
    	   g2.draw(path);
       }
       else
       { 
    	   PartyShape reciever = this.getAssociationList().get(message.getReciever());
    	   if(reciever == null || sender == null)
    		   return;
    	   if(this.getMessageMap().get(message) == null)
    		   this.createNewCoordinates(message);
    	   Coordinate temp = getMessageMap().get(message);
    	   this.adjustCoordinates(sender,reciever,temp);
    	   if(!(sender.getLine().hasActivationBarAt(sender.getLine().getX()-sender.getLine().getActivationBarWidth()/2, temp.getX())))
    		   sender.getLine().createActivationBar(sender.getLine().getX()-sender.getLine().getActivationBarWidth()/2, temp.getX()-sender.getLine().getActivationBarHeigth());
    	   if(!(reciever.getLine().hasActivationBarAt(reciever.getLine().getX(), temp.getY())))
    		   reciever.getLine().createActivationBar(reciever.getLine().getX()-reciever.getLine().getActivationBarWidth()/2, temp.getY()-sender.getLine().getActivationBarHeigth());
    	   Shape messageShape = this.getResultingShape(sender,reciever,temp.getX(),temp.getY(),index);
    	   int LabelX = this.getLabelX(sender, reciever);
   	       this.saveLabelCoordinate(message, LabelX, temp.getX()+(temp.getY()-temp.getX()));
           Shape stroked = stroke.createStrokedShape(messageShape);
           g2.draw(stroked);
           if(message.isActive())
        	   g.setColor(Color.RED);
   	       this.drawText(g,message,LabelX,temp.getX()+(temp.getY()-temp.getX()));
   	       g.setColor(Color.WHITE);
       }
	}

	
	
	
	
	




	private void clearAllBars(PartyShape sender) {
       sender.getLine().removeAllBars();		
	}




	
	private int getIndex(PartyShape sender) {
		int index =  1;
	    if(this.getMessageUnderConsX() > sender.getLineX())
  		   index  = 1;
  	   else 
  		   index = -1;
		return index;
	}

	private Shape getResultingShape(PartyShape sender, PartyShape reciever,int yFirst,int ySecond,int index) {
	   int distance = this.getDistance(sender.getLine().getX(),reciever.getLine().getX());
	   int distanceSecond = this.getDistance(reciever.getLine().getX(), sender.getLine().getX());
	   GeneralPath path = new GeneralPath();
	   int arrow = this.getArrow(sender.getLine().getX()+index*sender.getLine().getActivationBarWidth()/2,yFirst,reciever.getLine().getX(), ySecond);
	   path.moveTo(sender.getLine().getX()+distanceSecond*sender.getLine().getActivationBarWidth()/2,yFirst);
	   path.lineTo(reciever.getLine().getX()+distance*reciever.getLine().getActivationBarWidth()/2, ySecond);
	   path.moveTo(reciever.getLine().getX()+distance*reciever.getLine().getActivationBarWidth()/2+arrow, ySecond-5);
	   path.lineTo(reciever.getLine().getX()+distance*reciever.getLine().getActivationBarWidth()/2, ySecond);
	   path.moveTo(reciever.getLine().getX()+distance*reciever.getLine().getActivationBarWidth()/2+arrow, ySecond+5);
	   path.lineTo(reciever.getLine().getX()+distance*reciever.getLine().getActivationBarWidth()/2, ySecond);
	   return path;
	}
	





	private void adjustCoordinates(PartyShape sender, PartyShape reciever, Coordinate temp) {
        if(temp.getX() > sender.getLine().getY()+sender.getLine().getHeight() || temp.getX() < sender.getLine().getY())	{
        	sender.getLine().renewbarList();
        	int low = sender.getY()+sender.getHeight()+sender.getLine().getActivationBarHeigth();
        	int high = sender.getLine().getY()+sender.getLine().getHeight()-sender.getLine().getActivationBarHeigth();
            temp.setX(random.nextInt((high - low) + high) + low);
            sender.clearBars();
        }
        if(temp.getY() > reciever.getLine().getY()+reciever.getLine().getHeight() ||temp.getY() < reciever.getLine().getY()) {
        	reciever.getLine().renewbarList();
        	int low = reciever.getY()+reciever.getHeight()+reciever.getLine().getActivationBarHeigth();
        	int high = reciever.getLine().getY()+reciever.getLine().getHeight()-reciever.getLine().getActivationBarHeigth();
            temp.setY(random.nextInt((high - low) + high) + low);
            reciever.clearBars();
        }
	}


	private int getDistance(int x, int second) {
        if(x > second)
        	return 1;
		return -1;
	}







	private int getArrow(int x, int y, int xSecond, int ySecond) {
		if(x > xSecond)
			return 10;
		return -10;
	}

	@Override
	protected Message getIntersectingMessage(int x, int y) {
		for(Party party : this.getPartyList()) {
			for(Message message : party.getSenderList()) {
				Coordinate temp = this.getMap().get(message);
				if(temp !=null) {                              //Bug NEEDS to be solved efficiently.
				Shape rect = new Rectangle2D.Double(temp.getX(),temp.getY(),50,15);
				if(rect.contains(x,y))
					return message;
				}
			}
		}
		return null;
	}

	private HashMap<Message,Coordinate> getMap() {
		return map;
	}

	private void setMap(HashMap<Message,Coordinate> map) {
		this.map = map;
	}




	@Override
	protected void resize(int width, int height) {
		
	}





	



















	















		      
}











	
	




	