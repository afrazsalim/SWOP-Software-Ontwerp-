package diagramViews;

/**
 * A class which represents the coordinate of the shape.
 * @author Afraz Salim
 *
 */
public class Coordinate {
	/**
	 * A private variable which stores the x-coordiante.
	 */
	private int x;
	/**
	 * A private variable which stores the y-coordinate.
	 */
	private int y;
	/**
	 * A constructor which creates a new coordinate.
	 * @param x
	 *       The new x-coordinate with whcih the coordinate will be created.
	 * @param y
	 *       The y-coordiante with whcih the coordinate will be created.
	 */
	public Coordinate(int x, int y) {
		this.setX(x);
		this.setY(y);
	}
	/**
	 * A getter to get the x-coordiante.
	 * @return
	 *       Returns the x-coordinate.
	 */
	public int getX() {
		return x;
	}
	/**
	 * A setter to set the x-coordinate.
	 * @param x
	 *        The new x-coordinate.
	 */
	public void setX(int x) {
		this.x = x;
	}
	
	/**
	 * A getter to get the y-coordinate.
	 * @return
	 *       Returns the y-coordinate.
	 */
	public int getY() {
		return y;
	}
	/**
	 * A setter to set they y-coordinate.
	 * @param y
	 *        The new y-coordinate which will be set.
	 */
	public void setY(int y) {
		this.y = y;
	}

}
