package shapes;

import java.awt.Graphics2D;
import java.awt.Shape;

import diagramViews.DiagramView;
import domainObjects.Party;

/**
 * A class representing the partyshape.
 * @author Afraz Salim
 *
 */
public abstract class PartyShape {
	
	/**
	 * A private variable which stores the x-coordinate.
	 */
	private int x;
	/**
	 * A private variable which store the y-coordiante.
	 */
	private int y;
	/**
	 * A private variable whcih stores the width of the shape.
	 */
	private int width;
	/**
	 * A private variable which stores the height of the shape.
	 */
	private int height;
	/**
	 * A private variable which stores the line of the shape.
	 */
	private LineShape line;
	/**
	 * A private variable which stores the label.
	 */
	private Label label;
	private int lineX;
	private int lineY;
	private int lineWidth;
	private int lineHeight;
	private int labelX;
	private int labelY;
	private int labelWidth;
	private int labelHeight;
	private DiagramView diagram;
	/**
	 * A constructor to create the instance of the actor shape.
	 * @param diagram
	 *        The diagram of the partyShape.
	 * @param x
	 *        The x-Coordinate of the partyShape.
	 * @param y
	 *        The y-coordinate of the partyShape.
	 * @param width
	 *        The width of the party's shape.
	 * @param height
	 *        The height of the party's shape.
	 */
	public PartyShape(DiagramView diagram,int x, int y, int width, int height) {
		this.setX(x);
		this.setY(y);
		this.setWidth(width);
		this.setHeight(height);
		this.setDiagram(diagram);
	}
	
	
	
	/**
	 * A function to check if the shape contains the points.
	 * @param x
	 *        The given x-coordinate to be checked.
	 * @param y
	 *        The given y-coordiante to be checked.
	 * @return
	 *        Returns true if the shape contains the given points.
	 */
	public boolean contains(int x, int y) {
		if((x >= this.getX() && x <= this.getX()+this.getWidth() && y >= this.getY() && y <= this.getY()+this.getHeight())) 
			return true;
		return false;
	}
	
	/**
	 * A private variable to store the reference to the real party.
	 */
	private Party source;
	
	/**
	 * A getter to get the x-coordiante of the party.
	 * @return
	 *       Returns the x-coordinate of the party.
	 */
	public int getX() {
		return x;
	}
	
	/**
	 * A setter to set the x-coordinate of the shape.
	 * @param x
	 *        The x-coordinate which will be set as shape's coordiante.
	 */
	protected void setX(int x) {
		this.x = x;
	}
	
	/**
	 * A function to move the shape.
	 * @param x
	 *        The given x-coordiante on which the shape will be moved.
	 * @param y
	 *        The given y-coordiante on whcih the shape will be moved.
	 */
	public abstract void move(int x, int y);
	

	/**
	 * A getter to get the y-coordiante of the shape.
	 * @return
	 *       Returns the y-coordinate of the shape.
	 */
	public int getY() {
		return y;
	}
	
	/**
	 * A setter to set the y-coordinate of the shape.
	 * @param y
	 *       The given y-coordiante which will be set.
	 */
	protected void setY(int y) {
		this.y = y;
	}

	/**
	 * A getter to get the width of the shape.
	 * @return
	 *      Returns the width of the shape.
	 */
	public int getWidth() {
		return width;
	}
	/**
	 * A stter to set the width of the party's shape.
	 * @param width
	 *         The given width which will replaced the old width.
	 */
	protected void setWidth(int width) {
		this.width = width;
	}
	/**
	 * A getter to get the height of the party's shape.
	 * @return
	 *        Returns the height of the party's shape.
	 */
	public int getHeight() {
		return height;
	}
	/**
	 * A setter to set the height of the party's shape.
	 * @param height
	 *        The new height of the party's shape.
	 */
	protected void setHeight(int height) {
		this.height = height;
	}
	

	/**
	 * A function to get the shape of the party.
	 * @return
	 *       Returns the shape of the party.
	 */
	public abstract Shape getShape();




	

	/**
	 * A getter to get the real party associated with this shape.
	 * @return
	 *     returns the party associated with this shape.
	 */
	public Party getSource() {
		return source;
	}



	/**
	 * A stter to set the party as source of this shape.
	 * @param party
	 *       The party of the shape.
	 */
	public void setSource(Party party) {
		this.source = party;
	}



	/**
	 * A getter to get the lineShape of the arty's shape.
	 * @return
	 *       Returns the lineshape of the party's shape.
	 */
	public LineShape getLine() {
		return line;
	}


 
	/**
	 * A setter to set the lineshape of the partyShape.
	 * @param line
	 *        The line of the party.
	 */
	protected void setLine(LineShape line) {
		this.line = line;
	}



	/**
	 * A getter to get the label of the partyshape.
	 * @return
	 *       Returns the labelShape of the party shape.
	 */
	public Label getLabel() {
		return label;
	}



	/**
	 * A setter to set the label of the partyShape.
	 * @param label
	 *        The new label of the party shape.
	 */
	protected void setLabel(Label label) {
		this.label = label;
	}



	/**
	 * A getter to get the x-coordiante of the line
	 * @return
	 *       Returns the x-coordinate of the line.
	 */
	public int getLineX() {
		return lineX;
	}



	/**
	 * A setter to set the x-coordinate of the line.
	 * @param lineX
	 *        The x-coordinate of the lineShape.
	 */
	public void setLineX(int lineX) {
		this.lineX = lineX;
	}



	/**
	 * A getter to get the y-coordinate of the lineShape.
	 * @return
	 *       Returns the y-coordinate of the line.
	 */
	public int getLineY() {
		return lineY;
	}



	/**
	 * Sets the y-coordinate of the line.
	 * @param lineY
	 *        The new y-coordinate of the line.
	 */
	protected void setLineY(int lineY) {
		this.lineY = lineY;
	}



	/**
	 * A getter to get the height of the line shape.
	 * @return
	 *       Returns the height of the line shape.
	 */
	public int getLineHeight() {
		return lineHeight;
	}



	/**
	 * A setter to set the height of the line shape.
	 * @param lineHeight
	 *        The new height of the line shape.
	 */
	public void setLineHeight(int lineHeight) {
		this.lineHeight = lineHeight;
	}



	/**
	 * A getter to get the width of the line.
	 * @return
	 *       Returns the width of the line.
	 */
	public int getLineWidth() {
		return lineWidth;
	}



	/**
	 * A setter to set the width of the line.
	 * @param lineWidth
	 *        The new line widht of the party shape.
	 */
	public void setLineWidth(int lineWidth) {
		this.lineWidth = lineWidth;
	}



	/**
	 * A getter to get the x-coordinate of the label.
	 * @return
	 *        Returns the x-coordinate of the label.
	 */
	public int getLabelX() {
		return labelX;
	}



	/**
	 * A setter to set the x-coordinate of the label.
	 * @param labelX
	 *        The given x-coordinate of the label.
	 */
	protected void setLabelX(int labelX) {
		this.labelX = labelX;
	}



	/**
	 * A getter to get the y-coordinate of the label.
	 * @return
	 *       Returns the y-coordinate of the label.
	 */
	public int getLabelY() {
		return labelY;
	}



	/**
	 * A setter to set the y-coordinate of the label.
	 * @param labelY
	 *         The new y-coordinate of the label.
	 */
	protected void setLabelY(int labelY) {
		this.labelY = labelY;
	}



	/**
	 * A getter to get the width of the label.
	 * @return
	 *       Returns the width of the label.
	 */
	public int getLabelWidth() {
		return labelWidth;
	}



	/**
	 * A setter to set the width of the label.
	 * @param labelWidth
	 *        The new width of the label.
	 */
	protected void setLabelWidth(int labelWidth) {
		this.labelWidth = labelWidth;
	}



	/**
	 * A getter to get the height of the label.
	 * @return
	 *       Returns the height of the label.
	 */
	public int getLabelHeight() {
		return labelHeight;
	}



	/**
	 * A setter to set the height of the label.
	 * @param labelHeight
	 *        The new height of the label.
	 */
	protected void setLabelHeight(int labelHeight) {
		this.labelHeight = labelHeight;
	}



	/**
	 * A function which if the shape contains the given coordiante , will ask the diagram to move it.
	 * @param x
	 *        The given x-coordiante of to be checked.
	 * @param y
	 *        The given y-coordinate to be checked.
	 */
	public void drag(int x, int y) {
		 if(this.contains(x, y)) 
			   this.getDiagram().move(x,y,this.getSource());
	}


	/**
	 * A getter to get the diagram of the partyshape.
	 * @return
	 *       Returns the diagram of the partyshape.
	 */
	public DiagramView getDiagram() {
		return diagram;
	}



	
	private void setDiagram(DiagramView diagram) {
		this.diagram = diagram;
	}



	/**
	 * The coordinates on which the mouse is cliked.
	 * @param x
	 *        The given x-coordinate on which the mouse is clicked.
	 * @param y
	 *        The given y-coordinate on which the mouse is clicked.
	 */
	public void mouseClicked(int x, int y) {
      	if(this.getLabel().contains(x,y))
      		this.getLabel().setLabelActive(true);
	}
	



	/**
	 * A function which acts when mouse is double clicked.
	 * @param x
	 *        The x-coordinate on which the mouse is double clicked.
	 * @param y
	 *        The y-coordinate on which the mouse is double clicked.
	 */
	public void doubleClicked(int x, int y) {
 		if(this.contains(x, y))
 			this.getDiagram().convertPartyType(this.getX(),this.getY(),this.getSource());
	}



	/**
	 * A function which acts when the mouse button is released.
	 * @param x
	 *        The given x-coordinate on which the mouse is released.
	 * @param y
	 *        The given y-coordinate on which the mouse is released.
	 */
	public void releasedButtion(int x, int y) {
        if(this.getLine().contains(x, y)) {
        	if(!this.getLine().hasActivationBarAt(x, y))
        		this.getLine().createActivationBar(x-this.getLine().getActivationBarWidth()/2, y);
        	this.getDiagram().endMessageProcess(this,x,y);
        }
	}



	/**
	 * A function to draw Shapes.
	 * @param g2
	 *       The given instance of the graphics with which it draws shapes.
	 */
	public void paint(Graphics2D g2) {
		
	}



	/**
	 * A fucntion to check if the label is active.
	 * @return
	 *        Return true if the label is active.
	 */
	public boolean getHasActiveLabel() {
		return this.getLabel().isActive();
	}



	/**
	 * A fucntion to change the status of the label.
	 * @param value
	 *        The new boolean value of the label.
	 */
	public void setLabelActive(boolean value) {
        this.getLabel().setLabelActive(value);		
	}



	/**
	 * A function to remove the text from the label shape.
	 */
	public void removeText() {
       this.getLabel().removeText();		
	}



	/**
	 * A function to clear all bars from the line.
	 */
	public void clearBars() {
	}
	

}
