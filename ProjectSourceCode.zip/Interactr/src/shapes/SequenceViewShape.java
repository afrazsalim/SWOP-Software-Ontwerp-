package shapes;

import diagramViews.DiagramView;

/**
 * A class reprseting all the shapes in sequence view.
 * @author Afraz Salim
 
 *
 */
public abstract class SequenceViewShape extends PartyShape{

	/**
	 * A constructor to initialize the seuqence view shapes.
	 * @param diagram
	 *         The diagram of the shapes in sequence view.
	 * @param x
	 *        The x-coordinate of the sequence view shapes.
	 * @param y
	 *        The give y-coordinate of the sequence view shapes.
	 * @param width
	 *       The given width of the shape to becreated.
	 * @param height
	 *        The given height of the shape to be created.
	 */
	public SequenceViewShape(DiagramView diagram, int x, int y, int width, int height) {
		super(diagram, x, y, width, height);
	}
	

	/**
	 * A fucntion whcih responds if the mouse is dragged over a shapes line.
	 * It creates a new message if the coordiantes lie on some lineshape.
	 */
	@Override
	public void drag(int x, int y) {
		   super.drag(x, y);
		   if(this.getLine().contains(x, y)) {
			   this.getDiagram().createMessage(this.getLine().getX()+this.getLine().getActivationBarWidth()/2,y-this.getLine().getActivationBarHeigth()/3,this.getSource());
		   }
		}
}
