package shapes;

/**
 * A class representing the rectangle line shape.
 * @author Afraz Salim
 *
 */
public class RectangleLineShape extends LineShape {

	/**
	 * A construtor to create the new instance of rectangle line shape.
	 * @param x
	 *        The given x-coordinate of the rectangle line shape.
	 * @param y
	 *        The given y-coordinate of the rectangle line shape.
	 * @param width
	 *        The given width of the rectangle line shape.
	 * @param height
	 *        The given height of the rectangle line shape.
	 */
	public RectangleLineShape(int x, int y, int width, int height) {
		super(x, y, width, height);
	}


}
