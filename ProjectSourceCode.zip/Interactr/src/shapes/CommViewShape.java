package shapes;

import diagramViews.DiagramView;

/**
 * A class which represents a common interface for all the shapes in communication view.
 * @author Afraz Salim
 *
 */
public abstract class CommViewShape extends PartyShape {

	/**
	 * A constructor to initialize the coordinates of the shapes.
	 * @param diagram
	 *        The diagram of the shape.
	 * @param x
	 *        The new-Coordinate of the shape.
	 * @param y
	 *        The new y-coordinate of the shape.
	 * @param width
	 *        The given width of the shape.
	 * @param height
	 *        The given height of the shape.
	 */
	public CommViewShape(DiagramView diagram, int x, int y, int width, int height) {
		super(diagram, x, y, width, height);
	}

	/**
	 * If the mouse is dragged then this function will ask the digram to start creating message at given points.
	 * @param x
	 *        The given x-coordinate on which the message will be created.
	 * @param y
	 *        The given y-coordinate on which the message will be created.     
	 */
	@Override
	public void drag(int x, int y) {
       super.drag(x, y);
       if(this.getLine().contains(x, y) && !(this.contains(x, y))) {
		   this.getDiagram().createMessage(this.getLine().getX(),y,this.getSource());
	   }
	}

}
