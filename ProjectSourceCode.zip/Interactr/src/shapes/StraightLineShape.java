package shapes;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;

/**
 * A class representing the straight line shape.
 * @author Afraz Salim
 *
 */
public class StraightLineShape extends LineShape {

	/**
	 * A construtor to create the new instance of straight line shape.
	 * @param x
	 *        The given x-coordinate of the straight line shape.
	 * @param y
	 *        The given y-coordinate of the straight line shape.
	 * @param width
	 *        The given width of the straight line shape.
	 * @param height
	 *        The given height of the straight line shape.
	 */
	public StraightLineShape(int x, int y, int width, int height) {
		super(x, y, width, height);
		this.setActivationBarWidth(20);
		this.setActivationBarHeigth(35);
	}
	
	/**
	 * A function which draw the lineShapes.
	 */
	@Override
	public void draw(Graphics g) {
		  Graphics2D g2 = (Graphics2D) g;
	      this.getActivationBarList().stream().forEach(e ->{
	    	Shape rect = new Rectangle2D.Double(e.getX(),e.getY(),this.getActivationBarWidth(),this.getActivationBarHeigth());  
	        g.setColor(Color.BLUE);
	        g2.fill(rect);
	      });		
         g2.setColor(Color.WHITE);
	}
	

	
	/**
	 * A function which updates the y-coordinate of the activationbar.
	 * @param y
	 *        The y-coordinate of the activation bar.
	 */
	public void updateActicationBarY(int y) {
	   this.getActivationBarList().stream().forEach(e -> e.setY(e.getY() + (y-this.getY())));
	}

}
