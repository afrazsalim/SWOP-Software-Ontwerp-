package shapes;

import java.awt.Graphics;
import java.awt.Shape;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;

import diagramViews.Coordinate;

/**
 * A super-class representing the line of the party shape.
 * @author Afraz Salim
 *
 */
public abstract class LineShape {
	/**
	 * The given x-coordinate of the line.
	 */
	private int x;
	/**
	 * The given y-coordinate of the line.
	 */
	private int y;
	/**
	 * The given width of the line.
	 */
	private int width;
	/**
	 * The given height of the line.
	 */
	private int height;
	
	/**
	 * The given width of the activationbar.
	 */
	private int activationBarWidth;
	
	/**
	 * The given height of the activationBar.
	 */
	private int activationBarHeigth;
	
	/**
	 * A private list to store the coordinates of the activationbars.
	 */
	private ArrayList<Coordinate> activationBarList;
	/**
	 * A constructor to initialize the line.
	 * @param x
	 *        The given x-coordinate of the line.
	 * @param y
	 *        The given y-coordinate of the line.
	 * @param width
	 *        The given width of the line.
	 * @param height
	 *        The given height of the line.
	 */
	public LineShape(int x, int y, int width, int height) {
		this.setX(x);
		this.setY(y);
		this.setWidth(width);
		this.setHeight(height);
		this.setActivationBarWidth(4);
		this.setActivationBarHeigth(8);
		this.setActivationBarList(new ArrayList<>());
	}
	

	
	
	/**
	 * A getter to get the shape of the line.
	 * @return
	 *      Returns the shape of the line.
	 */
	public Shape getShape() {
       Shape rect = new Rectangle2D.Double(this.getX(),this.getY(),this.getWidth(),this.getHeight());
		return rect;
	}
	
	
	/**
	 * A checker to check if there is any activationbar at the give coordinates.
	 * @param x
	 *        The given x-coordinate to be checked.
	 * @param y
	 *       The given y-cordinate to be checked.
	 * @return
	 *       Returns true if the coordinates lies in specific range.
	 */
   public boolean hasActivationBarAt(int x, int y) {
	   for(Coordinate temp : this.getActivationBarList()) {
		   if(x >= temp.getX() && x <= temp.getX()+this.getActivationBarWidth() && y >= temp.getY() && y<= temp.getY()+this.getActivationBarHeigth())
			   return true;
	   }
	   return false;
   }
	
   /**
    * A getter to get the x-coordinate.
    * @return
    *       Returns the x-coordinate of the line.
    */
	public int getX() {
		return x;
	}
	/**
	 * A setter to set the x-coordinate.
	 * @param x
	 *        The new x value.
	 */
	protected void setX(int x) {
		this.x = x;
	}
	/**
	 * A getter to get the y-coordinate of the line.
	 * @return
	 *       Returns the y-coordinate of the line.
	 */
	public int getY() {
		return y;
	}
	
	/**
	 * A setter to set the y-coordinate of the line.
	 * @param y
	 *       The new value of line.
	 */
	protected void setY(int y) {
		this.y = y;
	}
	/**
	 * A getter to get the width of the line.
	 * @return
	 *      Returns the width of the line.
	 */
	public int getWidth() {
		return width;
	}
	/**
	 * A setter to set the width of the activation bar.
	 * @param width
	 *       The new width of the activation bar.
	 */
	protected void setWidth(int width) {
		this.width = width;
	}
	/**
	 * A getter to get the height of the activationbar.
	 * @return
	 *       Returns the height of the activation bar.
	 */
	public int getHeight() {
		return height;
	}
	/**
	 * A setter to set the height of the activation bar.
	 * @param height
	 *        The given new heigh of the activation bar.
	 */
	private void setHeight(int height) {
		this.height = height;
	}



	/**
	 * A checker to check if the line contrains a point.
	 * @param x
	 *       The given x-coordinate to be controlled.
	 * @param y
	 *       The given y-coordinate to be controlled.
	 * @return
	 *       Returns true if the line shape contains the given points.
	 */
	public boolean contains(int x, int y) {
		return this.getShape().contains(x,y);
	}




	/**
	 * Creates a new activation bar in terms of coordinates.
	 * @param x
	 *        The given x-coordinate on which an activationbar will be created.
	 * @param y
	 *       The given y-coordinate on which an activationbar will be created.
	 */
	public void createActivationBar(int x, int y) {
		this.getActivationBarList().add(new Coordinate(x,y));
	}
	
	




	/**
	 * A getter to get the activation bar width.
	 * @return
	 *        Returns the width of the activation bar.
	 */
	public int getActivationBarWidth() {
		return activationBarWidth;
	}




	/**
	 * A setter to set the activation bar width.
	 * @param activationBarWidth
	 * 
	 */
	protected void setActivationBarWidth(int activationBarWidth) {
		this.activationBarWidth = activationBarWidth;
	}




	/**
	 * A getter to get the activationbar height.
	 * @return
	 *       Returns the height of the activation bar.
	 */
	public int getActivationBarHeigth() {
		return activationBarHeigth;
	}




	/**
	 * A setter to set the height of the activationbar.
	 * @param activationBarHeigth
	 *        The given height of the activation bar with which the old value will be replaced.
	 */
	protected void setActivationBarHeigth(int activationBarHeigth) {
		this.activationBarHeigth = activationBarHeigth;
	}




	/**
	 * A function to get the list of the activationbars.
	 * @return
	 *       Returns the list of the activation bars.
	 */
	public ArrayList<Coordinate> getActivationBarList() {
		return activationBarList;
	}




	/**
	 * A setter to set the activationbar list.
	 * @param activationBarList
	 *        The new list with which the old one will be replaced.
	 */
	private void setActivationBarList(ArrayList<Coordinate> activationBarList) {
		this.activationBarList = activationBarList;
	}



	

	/**
	 * A functionw which draw the line shape and all activationbars.
	 * @param g
	 *       The given graphics instance with which the line draws itself.
	 */
	public void draw(Graphics g) {
	}






	/**
	 * A function to remove all the activation bars.
	 */
	public void removeAllBars() {
       this.setActivationBarList(new ArrayList<>());		
	}




	public void renewbarList() {
     this.setActivationBarList(new ArrayList<>());		
	}




}
