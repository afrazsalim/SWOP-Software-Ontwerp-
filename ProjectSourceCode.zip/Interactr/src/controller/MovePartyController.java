package controller;

import domainObjects.Interaction;

/**
 * A class which represents events to move a party.
 * @author Afraz Salim
 *
 */
public class MovePartyController extends InteractrDomainController{

	/***
	 * A constructor to create the new isntance of the controller.
	 * @param interaction
	 *        The given interaction of the party.
	 */
	public MovePartyController(Interaction interaction) {
		super(interaction);
	}

	/**
	 * A boolean checker to check if an operation can be proceeded.
	 */
	@Override
	protected boolean canProceed(Interaction window) {
		return true;
	}
	
	/**
	 * A checker to check if a move operation can be done.
	 * @return
	 *       Returns true if a move operation can be done.
	 */
	public boolean canMove() {
		return !(this.getWindow().hasAnyPartyLabelEnabled());
	}

}
