package controller;

import domainObjects.Interaction;
import domainObjects.Message;
import domainObjects.Party;

/**
 * A Controller class for handling the event related to the message.
 * @author Afraz Salim
 *
 */
public class AddMessageController extends InteractrDomainController {

	/**
	 * A constructor which initializes the controller.
	 * @param interaction
	 *        The current interaction
	 */
	public AddMessageController(Interaction interaction) {
		super(interaction);
	}

	

	/**
	 * A boolean checker to check if an operation can be proceed.
	 */
	@Override
	public boolean canProceed(Interaction window) {
		return true;
	}
	
	/**
	 * Creates a new message.
	 * @param party
	 *        A party which creates message.
	 * @param text
	 *        The initial text of the message.
	 * @return
	 *        Returns a new instance of the message.
	 */
	public Message createMessage(Party party, String text) {
		party.subscribe(this);
		return party.createMessage(text);
	}


	/**
	 * Finishes the message by adding the reciever to the message.
	 * @param sender
	 *        The sender of the message.
	 * @param reciever
	 *        The reciever of the message.
	 */
	public void finishMessageCreationProcess(Party sender, Party reciever) {
       	sender.finishMessageCreationProcess(reciever);
	}

	/**
	 * Creates a new resulting message.
	 * @param sender
	 *        The sender of the resuting message.
	 * @param reciever
	 *        The reciever of the resulting message.
	 * @param text
	 *         The given text of the message.
	 * @return
	 *        Returns a new instance of the resulting mssage.
	 */
	public Message createResultingMessage(Party sender, Party reciever, String text) {
		return sender.createResultingMessage(sender, reciever,text);
	}

}
