package controller;

import domainObjects.Interaction;
import domainObjects.Message;
import domainObjects.Party;

/**
 * A controller-class represeting the events related to label.
 * @author Afraz Salim
 *
 */
public class EditLabelController extends InteractrDomainController{

	/**
	 * A constructor to create new instance of the interaction
	 * @param interaction
	 *        The given current interaction .
	 */
	public EditLabelController(Interaction interaction) {
		super(interaction);
	}

	/**
	 * A function to check if a specific operation can be perfomed.
	 */
	@Override
	public boolean canProceed(Interaction window) {
		return !window.hasAnyPartyLabelEnabled();
	}
	
	/**
	 * Sets the label of the message enabled.
	 * @param source
	 *        The message whose label will be enabled.
	 */
	public void setLabelEnabled(Message source) {
       if(this.canProceed(this.getWindow())) {
    	   source.setlabelEnabled();
       }
	}
	
	

	


	/**
	 * A function to controle the verification.
	 * @param party
	 *        The party whoms text will be controlled.
	 * @param string
	 *        The string to be controlled.
	 */
	public void verifyText(Party party, String string) {
		     party.subscribe(this);
		     party.setLabelText(string);
		     party.verifyText();
	}

	


	/**
	 * A function to verify the text.
	 * @param source
	 *        The given message whose text will be verified.
	 */
	public void verifyText(Message source) {
    	  source.verifyText();
	}

	/**
	 * A function to enter the text into message.
	 * @param keyChar
	 *        The character to be inserted into the message's label.
	 * @param source
	 *        Message whom's label will be edited.
	 */
	public void enterText(char keyChar, Message source) {
	   source.subscribe(this);
       source.enterText(keyChar);		
	}

	/**
	 * A function to remove the the text from the message's label.
	 * @param message
	 *        The given message to remove the text.
	 */
	public void removeText(Message message) {
		message.removeText();		
	}

	

	
}
