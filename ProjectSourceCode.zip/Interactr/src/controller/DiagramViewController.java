package controller;

import java.util.ArrayList;

import Exceptions.IllegalObjectException;
import diagramViews.View;
import domainObjects.Interaction;

/**
 * A main class of the controllers to initialize all the controllers.
 * @author Afraz Salim
 *
 */
public class DiagramViewController {

	/**
	 * A private variable to store the interaction
	 */
	private Interaction state;

	/**
	 * A private variable to store the view.
	 */
	private View view;
	/**
	 * A private variable to store the instance of the addparty controller.
	 */
	private AddPartyController addPartyController;
	/**
	 * A private arrayList to store all the controllers.
	 */
	private ArrayList<InteractrDomainController> controllers;
	/**
	 * A private variable to store the controller.
	 */
	private EditLabelController labelEditor;
	/**
	 * A private variable to store the message controller instance.
	 */
	private AddMessageController messageController;
	
	/**
	 * A private variable to store the move controller message.
	 */
	private MovePartyController moveController;
	/**
	 * A constructor to create the instance of the main controller.
	 * @param interaction
	 *        The given interaction with which these controllers will be initialized.
	 * @throws IllegalObjectException
	 *        If the interaction is not an effective interaction then an exception will be thrown.
	 */
	public DiagramViewController(Interaction interaction) {
		if(interaction == null)
			throw new IllegalObjectException("interaction can't be null");
		this.setControllers(new ArrayList<>());
		this.setState(interaction);
		AddPartyController addParty = new AddPartyController(this.getState());
		EditLabelController labelEditor = new EditLabelController(this.getState());
		ConvertPartyTypeController converter = new ConvertPartyTypeController(this.getState());
		AddMessageController message = new AddMessageController(this.getState());
		MovePartyController move = new MovePartyController(this.getState());
		this.setMessageController(message);
		this.setAddpartyController(addParty);
		this.setEditLabelController(labelEditor);
		this.setPartyConverter(converter);
		this.setMoveController(move);
		this.getControllers().add(labelEditor);
		this.getControllers().add(moveController);
		this.getControllers().add(converter);
		this.getControllers().add(message);
		this.getControllers().add(move);
		this.getControllers().forEach(e -> this.getState().subscribe(e));
	}

	
	/**
	 * A private variable to store the instance of converted
	 */
	private ConvertPartyTypeController converter;

	/**
	 * A getter to get the convertPartyType controller.
	 * @return
	 *      Returns the convertPartytype controller.
	 */
	public ConvertPartyTypeController getConvertPartyTypeController() {
		return this.converter;
	}

	private void setPartyConverter(ConvertPartyTypeController converter) {
         this.converter = converter;		
	}


	

	/**
	 * A getter to get the editLabelHandler.
	 * @return
	 *       Returns the editlabel handler.
	 */
	public EditLabelController getEditLabelHandler() {
		return this.labelEditor;
	}
	
	private void setEditLabelController(EditLabelController labelEditor) {
          this.labelEditor = labelEditor;		
	}



	private void setAddpartyController(AddPartyController addParty) {
         this.addPartyController = 	addParty;
	}

	/**
	 * A getter to get the add party controller.
	 * @return
	 *       Returns the add party controller.
	 */
	public AddPartyController getAddPartyController() {
		return this.addPartyController;
	}

	


	

	/**
	 * A getter to get the current interaction.
	 * @return
	 *      Returns the current interaction.
	 */
	protected Interaction getState() {
		return state;
	}


	private void setState(Interaction state) {
		this.state = state;
		this.getControllers().stream().forEach(e -> e.setWindow(this.getState()));
	}


	
	
    
	private ArrayList<InteractrDomainController> getControllers() {
		return controllers;
	}


	private void setControllers(ArrayList<InteractrDomainController> controllers) {
		this.controllers = controllers;
	}

	/**
	 * A getter to get the message controller.
	 * @return
	 *       Returns the instance of the message controller.
	 */
	public AddMessageController getMessageController() {
		return this.messageController;
	}

	
	private void setMessageController(AddMessageController messageController) {
		this.messageController = messageController;
	}

	/**
	 * A getter to get the move party controller
	 * @return
	 *       Returns the move party controller.
	 */
	public MovePartyController getMoveController() {
		return moveController;
	}

	private void setMoveController(MovePartyController moveController) {
		this.moveController = moveController;
	}

	/**
	 * A getter to get the current interaction.
	 * @return
	 *       Returns the current interaction.
	 */
	public Interaction getWindow() {
		return this.getState();
	}

	
	
}
