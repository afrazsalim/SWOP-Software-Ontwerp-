package controller;

import Exceptions.IllegalOperationExcetion;
import domainObjects.Interaction;
import domainObjects.Party;
/**
 * 
 * @author Afraz Salim
 *
 */
public class ConvertPartyTypeController extends InteractrDomainController {

	/**
	 * A class which provides functions to convert an object type to other object.
	 * @param interaction
	 *        The window in which the object lies.
	 */
	public ConvertPartyTypeController(Interaction interaction) {
		super(interaction);
	}


	/**
	 * A checker to check whether a specific operation can be performed.
	 */
	@Override
	public boolean canProceed(Interaction window) {
		return (!window.hasAnyPartyLabelEnabled());
	}

	
	/**
	 * A function which forwards the request to the window for the conversion of the objects.
	 * @param party
	 *        The object which should be converted.
	 */
	public void convertPartyType(Party party) {
	 if(this.canProceed(this.getWindow())) {
       this.getWindow().subscribe(this);
       try {
         this.getWindow().convertParty(party);
       }catch(IllegalOperationExcetion exc) {
    	   System.out.println(exc.toString());
       }
	 }
	}
	
	
}

