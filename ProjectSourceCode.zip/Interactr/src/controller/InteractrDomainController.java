package controller;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import domainObjects.Interaction;
import domainObjects.Party;

/**
 * A super class for all the controller.
 * @author Afraz Salim
 *
 */
public abstract class InteractrDomainController implements PropertyChangeListener {

	/**
	 * A variable to store the interaction
	 */
	private Interaction window;
	/**
	 * A propertychange support variable.
	 */
    private PropertyChangeSupport pcs = new PropertyChangeSupport(this);
    

	
    /**
     * A controller constructor to initialize the values.
     * @param interaction
     *        The given interaction with which the controlller will be initialized.
     */ 
	public InteractrDomainController(Interaction interaction) {
      this.setWindow(interaction);
      window.subscribe(this);
	}
	
	/**
	 * A function where different listeners can unsubscribe.
	 * @param listener
	 *        The listener who wants to unsubscribe.
	 */
	public void unSubscribe(PropertyChangeListener listener) {
	       this.pcs.removePropertyChangeListener(listener);		
		}

	/**
	 * A function where different listeners can subscribe.
	 * @param listener
	 *        The listener who wants to subscribe.
	 */
	public void subscribe(PropertyChangeListener listener) {
		this.pcs.addPropertyChangeListener(listener);
	}
	
	/**
	 * A function to send the notification.
	 * @param event
	 *        The given event which will be fired.
	 */
	public void sendNotification(PropertyChangeEvent event) {
         this.pcs.firePropertyChange(event);		
	}
	
	
	
	/**
	 * A propertychangeEvent which listens to the domain objects.
	 */
	@Override
	public void propertyChange(PropertyChangeEvent event) {
	switch(event.getPropertyName()) {
		case "MessageFinished" : this.sendNotification(event);
		      break;
		case "MessageCreated" : this.sendNotification(event);
		      break;
		case "MessageUpdatedSecondPoint" : this.sendNotification(event);
		      break;
		case "RemoveMessage": this.sendNotification(event);
		      break;
		case "MessageUpdatedFirstPoint": this.sendNotification(event);
		      break;
		case "CreatedParty" : this.subscribeToParty((Party) event.getNewValue());
			                 this.sendNotification(event);
		      break;
		case "RemoveParty" : this.sendNotification(event);
		      break;
		case "ChangedWindowCoords" : this.sendNotification(event);
		      break;
		case "changedSize" : this.sendNotification(event);
		      break;
		case "labelEnabled" :this.sendNotification(event);
		      break;
		case "LabelEdited" : this.sendNotification(event);
		      break;
		case "LabelVerified" : this.sendNotification(event);
		      break;
		case "MessageLabelEdited" : this.sendNotification(event);
		      break;
		case "updatedCoords" : this.sendNotification(event);
		      break;
		case "ConvertedParty" : this.sendNotification(event);
		      break;
		}
	}    
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    /**
     * Subscribes to the party.
     * @param party
     *        The given party to which controller subscribes.
     */
	private void subscribeToParty(Party party) {
        party.subscribe(this);
	}


	/**
	 * A function to check if an operation can be proceeded.
	 * @param interaction
	 *        The given current interaction of the controller.
	 * @return
	 *        Returns true if operation can be performed.
	 */
	protected abstract boolean canProceed(Interaction interaction);

	/**
	 * A getter to get interaction window.
	 * @return
	 *       Returns the interaction window.
	 */
	protected Interaction getWindow() {
		return window;
	}

	/**
	 * A setter to set the interaction window.
	 * @param interaction
	 *        The give current interaction
	 */
	protected void setWindow(Interaction interaction) {
		this.window = interaction;
		if(interaction != null)
		  this.window.subscribe(this);
	}
	
	
}
