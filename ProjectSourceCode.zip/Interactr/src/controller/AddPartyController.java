package controller;

import Exceptions.IllegalOperationExcetion;
import domainObjects.Interaction;
import domainObjects.Party;

/**
 * 
 * @author Afraz Salim
 *A controller class to create an interaction window.
 */
public class AddPartyController extends InteractrDomainController{

	/**
	 * 
	 * @param sequenceView
	 *        The given window to which will be called on.
	 */
	protected AddPartyController(Interaction sequenceView) {
		super(sequenceView);

	}
	
	/**
	 * A function to remove the party from the interaction.
	 * @param party
	 *        The give party to be removed.
	 */
	public void remove(Party party) {
		this.getWindow().removeParty(party);
	}




	/**
	 * A checker to check whether an operation is possible.
	 */
	@Override
	public boolean canProceed(Interaction window) {
		return !window.hasAnyPartyLabelEnabled();
	}
	
	

	

	/**
	 * A function which creates an Actor.
	
	 * @param text
	 *       Label text of a party.
	 * @exception IllegalOperationExcetion
	 *     if the given window is invalid, an exception will be thrown.
	 * 
	 */     
	public void createActor(String text) {
		try {
			   this.getWindow().createNewActor(text);
		}catch(IllegalOperationExcetion exc) {
			System.out.println(exc.toString());
		}
	
	}






	


     




	/**
	 * Creates a new party object.
	 * @param string
	 *        The initial label text of the party object.
	 * @exception IllegalOperationExcetion
	 *        An illegalOperationException will be thrown if window is not a valid window.
	 */
	public void createPartyObject(String string) {
		try {
			 this.getWindow().createNewPartyObject(string);
		}catch(IllegalOperationExcetion exc) {
			System.out.println(exc.toString() + "A null is being returned");
		}
	 }



}
