package domainObjects;

/**
 * A class representing the Invocation Message.
 * @author afraz
 *
 */
public class InvocationMessage extends Message {

	/**
	 * A constructor to create the instance of the InvocationMessage.
	 *
	 * @param sender
	 *        The sender of the message.
	 * @param text
	 *        The given intital text of the message.
	 */
	public InvocationMessage(Party sender, String text) {
		super(sender,text);
	}

}
