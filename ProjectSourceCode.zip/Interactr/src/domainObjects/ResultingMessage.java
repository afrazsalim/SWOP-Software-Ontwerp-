package domainObjects;

/**
 * A class representing the resulting message.
 * @author afraz
 *
 */
public class ResultingMessage extends Message {

	/**
	 * A constructor to create a new resulting message.
	 * @param sender
	 *        The sender of the resulting message.
	 * @param text
	 *        The initial text of the resulting message.
	 */
	public ResultingMessage(Party sender, String text) {
		super(sender,text);
	}

}
