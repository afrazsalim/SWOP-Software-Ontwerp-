package domainObjects;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.ArrayList;

import Exceptions.IllegalOperationExcetion;

/**
 * 
 * @author Afraz Salim
 *
 */
public class Message {
	/**
	 * The label text of the Message.
	 */
	private String labelText;
	/**
	 * Sender of the message.
	 */
	private Party sender;
	/**
	 * Reciever of the message.
	 */
	private Party reciever;
	/**
	 * Message number.
	 */
	private static int number = 1;
	/**
	 * Propertychange support.
	 */
    private PropertyChangeSupport pcs;
    /**
     * A string which indicates that the message label has been edited.
     */
    private static final String MessageLabelEdited = "MessageLabelEdited";
    /**
     * A string which indicates that the message label has been verified.
     */
    private static final String MessageVerified = "MessageVerified";
    /**
     * A list of Listeners.
     */
    private ArrayList<PropertyChangeListener> listenerList;
    /**
     * Chracter list of the message label.
     */
    private ArrayList<Character> charactersList;
    /**
     * Number of the message.
     */
    private int messageNumber;
    
    
    /**
     * A constructor to initialize the message.
     * @param sender
     *        Sender of the message.
     * @param text
     *        Label's text of the message.
     * @throws IllegalOperationExcetion
     *        Throws illegalOperationException if the the sender of the message is null.
     */
	public Message(Party sender,String text) {
		if(sender == null)
			throw new IllegalOperationExcetion("Every Message must have a sender party");
		this.setSender(sender); 
		setListenerList(new ArrayList<>());
		 pcs = new PropertyChangeSupport(this);
		this.setCharactersList(new ArrayList<>());
		if(!(this instanceof ResultingMessage))
		    this.setActive(false);
		this.setMessageNumber(getNumber());
		setNumber(getNumber()+1);
		this.setLabelText("");
	}
	
	
	/**
	 * Provides a function to subscribe.
	 * @param listener
	 *        A listener to be added.
	 */
    public void subscribe(PropertyChangeListener listener) {
    	if(!(this.getListenerList().contains(listener))) {
		 this.pcs.addPropertyChangeListener(listener);
		 this.getListenerList().add(listener);
    	}
    }


    /**
     * A getter to get the label text.
     * @return
     *        Returns the label's text.
     */
	public String getLabelText() {
		return labelText;
	}
	
	/**
	 * A string representing the message number.
	 */
	private String messageNumbers;
	
	/**
	 * A setter to set the message label's text.
	 * @param labelText
	 *        The new text which will be set.
	 */
	private void setLabelText(String labelText) {
		StringBuilder stringBuilder = new StringBuilder();
		for(int i  = 0; i < this.getMessageNumber();i++) {
			stringBuilder.append("" + i+":");
		} 
		String finalString = stringBuilder.toString();
		this.setMessageNumbers(finalString);
		this.labelText =  finalString+labelText ;
	}

	/**
	 * A getter to get the sender of the message.
	 * @return
	 *       Returns the sender of the message.
	 */
	public Party getSender() {
		return sender;
	}

	/**
	 * A setter to set the sender of the message.
	 * @param sender
	 *        The new sender of the message.
	 */
	protected void setSender(Party sender) {
		this.sender = sender;
	}

	/**
	 * A getter ot get the reciever of the message.
	 * @return
	 *       Returns the reciever of the message.
	 */
	public Party getReciever() {
		return reciever;
	}

	/**
	 * A setter to set the reciever of the message.
	 * @param reciever
	 *         The new reciever of the messagE.
	 */
	protected void setReciever(Party reciever) {
		this.reciever = reciever;
	}



	




	/**
	 * A list of all the listeners.
	 * @return
	 *       Returns the list of the all listeners.
	 */
	private ArrayList<PropertyChangeListener> getListenerList() {
		return listenerList;
	}



	/**
	 * Sets the list of all the listeners.
	 * @param listenerList
	 *         The new list of the listeners.
	 */
	private void setListenerList(ArrayList<PropertyChangeListener> listenerList) {
		this.listenerList = listenerList;
	}


	/**
	 * A boolean variable to check if the message label is active.
	 */
	private boolean isActive;

	/**
	 * A checker to check if any message has active label.
	 * @return  
	 *       Returns true if the message is active.
	 */
	public boolean isActive() {
		return this.isActive;
	}
	
	/**
	 * A setter to change the active status of the message's label.
	 * @param value
	 *        The new value with which the old value will be replaced.
	 */
	protected void setActive(boolean value) {
		this.isActive = value;
	}


	

	/**
	 * Verfies and turns off the label if label is valid.
	 */
	public void verifyText() {
      this.setActive(false);
      this.sendNotifications(MessageVerified, "", "");
	}



	/**
	 * A function to enter the characters into the message's label text.
	 * @param keyChar
	 *        The keyChar which will be inserted at the end of the label.
	 */
	public void enterText(char keyChar) {
        this.getCharactersList().add(keyChar);	
        if(this.getCharactersList().size() >  0)
        	this.setLabelText(this.getCharactersList().stream().map(e->e.toString()).reduce((acc, e) -> acc + e).get());
        this.sendNotifications(MessageLabelEdited, "", this.getMessageNumbers()+this.getLabelText());
	}


    /**
     * A list of all characters.
     * @return
     *       Retruns the list of all the character of message's label.
     */
	private ArrayList<Character> getCharactersList() {
		return charactersList;
	}



	/**
	 * A setter to set the characters list.
	 * @param charactersList
	 *        The new chracters list with which the old list will be replaced.
	 */
	private void setCharactersList(ArrayList<Character> charactersList) {
		this.charactersList = charactersList;
	}



	/**
	 * A function to remove the characters from the end of the Message's label.
	 */
	public void removeText() {
		if(this.getCharactersList().size() <= 0)
			  throw new IllegalOperationExcetion("Label has no element to print");
	      this.getCharactersList().remove(this.getCharactersList().size()-1);		
	      String oldText = this.getLabelText();
	      if(this.getCharactersList().size() > 0)
	         this.setLabelText(this.getCharactersList().stream().map(e->e.toString()).reduce((acc, e) -> acc + e).get());
	      else
	    	  this.setLabelText("");
	      this.sendNotifications(MessageLabelEdited, oldText, this.getMessageNumbers()+this.getLabelText());
	}



	/**
	 * Sends the notifications to all listeners.
	 * @param propertyName
	 *        The propertyName of the event.
	 * @param oldText
	 *        Old text of message's label.
	 * @param labelText
	 *        New text of the message's label.
	 */
	private void sendNotifications(String propertyName, String oldText, String labelText) {
       PropertyChangeEvent event = new PropertyChangeEvent(this.getSender(),"MessageLabelEdited",oldText,labelText);
       this.pcs.firePropertyChange(event);
	}


	

	/**
	 * Sets the label of the message enabled.
	 */
	public void setlabelEnabled() {
      this.setActive(true);	
      this.sendNotifications("","", this.getLabelText());
	}



	/**
	 * A getter to get the number of the message.
	 * @return
	 *        Returns the message's number.
	 */
	private static int getNumber() {
		return number;
	}



	/**
	 * A setter to set the message's number.
	 * @param number
	 *        The number of the message.
	 */
	private static void setNumber(int number) {
		Message.number = number;
	}



	/**
	 * A getter to get the message's number.
	 * @return
	 *        Returns the string representation of the number.
	 */
	private String getMessageNumbers() {
		return messageNumbers;
	}



	/**
	 * A setter to set the message number in terms of string.
	 * @param messageNumbers
	 *        A new string reprsentation of the number.
	 */
	private void setMessageNumbers(String messageNumbers) {
		this.messageNumbers = messageNumbers;
	}



	/**
	 * A getter to get the message number.
	 * @return
	 *       Returns the message number.
	 */
	private int getMessageNumber() {
		return messageNumber;
	}



	/**
	 * A setter to set message number.
	 * @param messageNumber
	 *        The new number of the messagE.
	 */
	private void setMessageNumber(int messageNumber) {
		this.messageNumber = messageNumber;
	}



	/**
	 * Reduces the message's number by 1.
	 */
	protected static void reducNumber() {
      if(getNumber() > 0)
    	  setNumber(getNumber()-1);
	}
	
	
	
	
}
